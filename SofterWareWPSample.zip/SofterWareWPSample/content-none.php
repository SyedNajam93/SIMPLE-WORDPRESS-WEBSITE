<?php
/*
# =================================================
# content-none.php
#
# The template to be displayed for missing content.
# =================================================
*/
?>

<?php _e( 'Nothing found!', 'tuts' ); ?>
